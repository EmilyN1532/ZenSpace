//
//  HelplineController.swift
//  ZenSpace
//
//  
//  Copyright © 2020 Emily Nolan. All rights reserved.
//

import UIKit

class HelplineController: UIViewController {
    
    // Properties
        
        private let logoImageView: UIImageView = {
            let iv = UIImageView()
            iv.contentMode = .scaleAspectFit
            iv.image = #imageLiteral(resourceName: "Helpline")
            return iv
        }()
        
        
        
        
        // Lifecycle
        
        override func viewDidLoad() {
            super.viewDidLoad()
            configureUI()
        }
        
        // Selectors
        
        
        
        
        // Helpers

        func configureUI() {
            view.backgroundColor = .HelplineBackground
            navigationController?.navigationBar.barStyle = .black
            navigationController?.navigationBar.isHidden = false
            navigationItem.title = "Helplines"
            
           view.addSubview(logoImageView)
           logoImageView.centerX(inView: view, topAnchor: view.safeAreaLayoutGuide.topAnchor)
           logoImageView.setDimensions(width: 400, height: 600)
         
        
    }

}






       
  
