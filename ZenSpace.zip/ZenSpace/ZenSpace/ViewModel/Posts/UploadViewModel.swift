//
//  UploadViewModel.swift
//  ZenSpace
//
//  Created by Emily Code on 03/08/2020.
//  Copyright © 2020 Emily Nolan. All rights reserved.
//

import UIKit

enum UploadPostConfiguration {
    case post
    case reply(Post)
}

struct UploadPostViewModel {
    
    let actionButtonTitle: String
    let placeholderText: String
    var shouldShowReplyLabel: Bool
    var replyText: String?
    
    init(config: UploadPostConfiguration) {
        switch config {
        case .post:
            actionButtonTitle = "Post"
            placeholderText = "What's happening?"
            shouldShowReplyLabel = false
        case .reply(let post):
            actionButtonTitle = "Reply"
            placeholderText = "Post your reply"
            shouldShowReplyLabel = true
            replyText = "Replying to @\(post.user.username)"
        }
    }
}
